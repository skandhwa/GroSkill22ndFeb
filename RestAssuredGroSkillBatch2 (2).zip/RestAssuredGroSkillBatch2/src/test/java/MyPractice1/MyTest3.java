package MyPractice1;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import Payload.TestData1;

public class MyTest3 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all().headers("Content-type","application/json")
		.body(TestData1.AddDetails("Tom","QA Manager"))
		.when().post("api/users")
		.then().assertThat().statusCode(201)
		.extract().response().asString();
	
	System.out.println(Response);
		
		
		
		
		

	}

}
