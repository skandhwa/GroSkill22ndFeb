package MyPractice1;

import org.testng.Assert;

import MockJsonResponse.JsonData;
import io.restassured.path.json.JsonPath;

public class TestCaseMockJSON {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(JsonData.JSONData());
		
		///Print No of courses returned by API
		
	int noOfCourses=	js.getInt("courses.size()");
	System.out.println("The total number of courses is  "+noOfCourses);
	
		////Print purchase amount
	
	int purchaseAmount=js.getInt("dashboard.purchaseAmount");
	System.out.println("The total purchase amount is "+purchaseAmount);
		
	///Print Title of the first course
	
String title_firstcourse=	js.getString("courses[0].title");

System.out.println("The title of first course is  "+title_firstcourse);

		
		///Print All course titles and their respective Prices

System.out.println("The title of course and respective prices are");

for(int i=0;i<noOfCourses;i++)
{
	String CourseTitle=  js.getString("courses["+i+"].title");
	int CoursePrice=  js.getInt("courses["+i+"].price");
	System.out.print(CourseTitle+"  ");
	System.out.println(CoursePrice);
	
	
}


///Verify if Sum of all Course prices matches with Purchase Amount

System.out.println("Verify if Sum of all Course prices matches with Purchase Amount");

int sum=0;
for(int i=0;i<noOfCourses;i++)
{
	int CourseCopies=  js.getInt("courses["+i+"].copies");
	int CoursePrice=  js.getInt("courses["+i+"].price");
	System.out.print(CourseCopies+"  ");
	System.out.println(CoursePrice);
	
	int amount=CourseCopies*CoursePrice;
	
	
	sum=sum+amount;
	
}

System.out.println("The total sum of all courses are  "+sum);

Assert.assertEquals(purchaseAmount, sum);

System.out.println("Amount is verified and it is correct");



		
		
		

	}

}
