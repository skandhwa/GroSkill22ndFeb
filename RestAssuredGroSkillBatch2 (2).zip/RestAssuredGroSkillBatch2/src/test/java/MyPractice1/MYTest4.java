package MyPractice1;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;
import java.util.Map;

import Payload.TestData1;
import io.restassured.RestAssured;

public class MYTest4 {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://reqres.in";
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("name","Harry");
		mp.put("job","QA Manager");
		mp.put("salary", 95000f);
		mp.put("isMarried", true);
		
		
		
		String Response=	given().log().all().headers("Content-type","application/json")
			.body(mp)
			.when().post("api/users")
			.then().assertThat().statusCode(201)
			.extract().response().asString();
		
		System.out.println(Response);
			

	}

}
